﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace shopbanhoa.Product
{
    public partial class BoHoaLon : System.Web.UI.UserControl
    {
        shopbanhoatuoiDataContext db = new shopbanhoatuoiDataContext();
        public static List<SanPham> listSP = new List<SanPham>();

        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadDataDT();
        }


        // truyền dữ liệu khi thêm vào đặt hàng ---------------------------------------------------
        void LoadDataDT()
        {
            try
            {
                if (Request.QueryString["MaSP"] != null && Request.QueryString["quantity"] != null)
                {
                    string maSP = Request.QueryString["MaSP"];
                    int quantity = Convert.ToInt32(Request.QueryString["quantity"]);

                    
                }
                else
                {
                   //
                }
            }
            catch (Exception ex)
            {
                Response.Redirect("Error.aspx?message=Lỗi khi xử lý dữ liệu sản phẩm");
            }
        }

        //----------------------------------------------------------------------------------
        void LoadData()
        {
            var data = from q in db.SanPhams
                       where q.MaLoai == 9
                       orderby q.GiaBan ascending
                       select q;
            if (data != null && data.Count() > 0)
            {
                listSP = data.ToList();
            }
        }
    }
}